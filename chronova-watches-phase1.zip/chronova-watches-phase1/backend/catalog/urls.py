from django.urls import path
from .views import ProductListView, CategoryListView, SellerListView

urlpatterns = [
    path("products/", ProductListView.as_view(), name="product-list"),
    path("categories/", CategoryListView.as_view(), name="category-list"),
    path("sellers/", SellerListView.as_view(), name="seller-list"),
]
