from decimal import Decimal
from django.core.management.base import BaseCommand
from catalog.models import Seller, Category, Product


class Command(BaseCommand):
    help = "Create demo sellers, categories, and watch products."

    def handle(self, *args, **options):
        seller1, _ = Seller.objects.update_or_create(
            store_name="Golden Time Boutique",
            defaults={
                "owner_name": "Demo Seller One",
                "email": "golden@example.com",
                "city": "Salem",
                "description": "Classic and premium everyday watches.",
                "status": "approved",
            },
        )
        seller2, _ = Seller.objects.update_or_create(
            store_name="Urban Tick Store",
            defaults={
                "owner_name": "Demo Seller Two",
                "email": "urban@example.com",
                "city": "Chennai",
                "description": "Modern styles for everyday use.",
                "status": "approved",
            },
        )

        categories = {}
        for name in ["Men", "Women", "Digital", "Luxury"]:
            category, _ = Category.objects.get_or_create(name=name)
            categories[name] = category

        demo_products = [
            {
                "sku": "CHR-MEN-001", "seller": seller1, "category": categories["Men"],
                "name": "Classic Steel Watch", "brand": "Chronova Select",
                "description": "A clean everyday watch with a stainless-steel look.",
                "price": Decimal("2499.00"), "compare_at_price": Decimal("2999.00"),
                "stock_quantity": 12, "warranty_months": 12,
                "image_url": "https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=800",
            },
            {
                "sku": "CHR-WOM-001", "seller": seller2, "category": categories["Women"],
                "name": "Rose Gold Elegance", "brand": "Urban Tick",
                "description": "Elegant rose-gold styling for daily and special occasions.",
                "price": Decimal("3199.00"), "compare_at_price": Decimal("3599.00"),
                "stock_quantity": 8, "warranty_months": 12,
                "image_url": "https://images.unsplash.com/photo-1523170335258-f5ed11844a49?w=800",
            },
            {
                "sku": "CHR-DIG-001", "seller": seller1, "category": categories["Digital"],
                "name": "Sport Digital Watch", "brand": "TimeTrail",
                "description": "Sport-inspired digital style for everyday activities.",
                "price": Decimal("1299.00"), "compare_at_price": None,
                "stock_quantity": 20, "warranty_months": 6,
                "image_url": "https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?w=800",
            },
            {
                "sku": "CHR-LUX-001", "seller": seller2, "category": categories["Luxury"],
                "name": "Midnight Luxe", "brand": "Urban Tick Premium",
                "description": "A bold dark dial with a premium-inspired finish.",
                "price": Decimal("5999.00"), "compare_at_price": Decimal("6499.00"),
                "stock_quantity": 5, "warranty_months": 12,
                "image_url": "https://images.unsplash.com/photo-1547996160-81dfa63595aa?w=800",
            },
        ]

        for item in demo_products:
            Product.objects.update_or_create(sku=item["sku"], defaults=item)

        self.stdout.write(self.style.SUCCESS("Demo sellers, categories, and watches are ready."))
