from django.contrib import admin
from .models import Seller, Category, Product


@admin.register(Seller)
class SellerAdmin(admin.ModelAdmin):
    list_display = ("store_name", "owner_name", "city", "status", "created_at")
    list_filter = ("status", "city")
    search_fields = ("store_name", "owner_name", "email", "phone")
    list_editable = ("status",)


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "slug")
    search_fields = ("name",)


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ("name", "brand", "seller", "category", "price", "stock_quantity", "is_active")
    list_filter = ("is_active", "category", "seller")
    search_fields = ("name", "brand", "sku", "seller__store_name")
    list_editable = ("price", "stock_quantity", "is_active")
