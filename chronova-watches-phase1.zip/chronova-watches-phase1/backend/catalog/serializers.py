from rest_framework import serializers
from .models import Seller, Category, Product


class SellerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Seller
        fields = ["id", "store_name", "owner_name", "city", "description", "status"]


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ["id", "name", "slug"]


class ProductSerializer(serializers.ModelSerializer):
    seller_name = serializers.CharField(source="seller.store_name", read_only=True)
    seller_city = serializers.CharField(source="seller.city", read_only=True)
    category_name = serializers.CharField(source="category.name", read_only=True)

    class Meta:
        model = Product
        fields = [
            "id", "name", "brand", "description", "price", "compare_at_price",
            "sku", "stock_quantity", "image_url", "warranty_months",
            "seller", "seller_name", "seller_city", "category", "category_name",
        ]
