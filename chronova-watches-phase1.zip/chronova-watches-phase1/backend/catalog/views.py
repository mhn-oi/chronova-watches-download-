from rest_framework import generics
from rest_framework.permissions import AllowAny
from .models import Seller, Category, Product
from .serializers import SellerSerializer, CategorySerializer, ProductSerializer


class ProductListView(generics.ListAPIView):
    serializer_class = ProductSerializer
    permission_classes = [AllowAny]

    def get_queryset(self):
        queryset = Product.objects.filter(
            is_active=True,
            seller__status="approved",
            stock_quantity__gt=0,
        ).select_related("seller", "category")

        search = self.request.query_params.get("search", "").strip()
        category = self.request.query_params.get("category", "").strip()
        if search:
            from django.db.models import Q
            queryset = queryset.filter(
                Q(name__icontains=search)
                | Q(brand__icontains=search)
                | Q(description__icontains=search)
                | Q(seller__store_name__icontains=search)
            )
        if category:
            queryset = queryset.filter(category__slug=category)
        return queryset


class CategoryListView(generics.ListAPIView):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [AllowAny]


class SellerListView(generics.ListAPIView):
    queryset = Seller.objects.filter(status="approved")
    serializer_class = SellerSerializer
    permission_classes = [AllowAny]
