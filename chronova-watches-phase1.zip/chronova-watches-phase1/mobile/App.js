import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator, Alert, FlatList, Image, Pressable, RefreshControl,
  SafeAreaView, ScrollView, StatusBar, StyleSheet, Text, TextInput, View
} from "react-native";
import { API_BASE_URL } from "./src/config";

const GOLD = "#E4B95F";
const BG = "#08111F";
const PANEL = "#121D2C";
const MUTED = "#9AA7B8";
const DEMO = [
  { id: "demo-1", name: "Classic Steel Watch", brand: "Chronova Select", price: "2499", compare_at_price: "3299", image_url: "https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=800", seller_name: "Golden Time Boutique", seller_city: "Salem", category_name: "Men", stock_quantity: 12, warranty_months: 12, description: "A timeless stainless-steel design for everyday style." },
  { id: "demo-2", name: "Rose Gold Elegance", brand: "Urban Tick", price: "3199", compare_at_price: "3999", image_url: "https://images.unsplash.com/photo-1523170335258-f5ed11844a49?w=800", seller_name: "Urban Tick Store", seller_city: "Chennai", category_name: "Women", stock_quantity: 8, warranty_months: 12, description: "Elegant rose-gold styling for special moments." },
  { id: "demo-3", name: "Sport Digital Watch", brand: "TimeTrail", price: "1299", compare_at_price: "1799", image_url: "https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?w=800", seller_name: "Golden Time Boutique", seller_city: "Salem", category_name: "Digital", stock_quantity: 20, warranty_months: 6, description: "A sporty everyday companion with a modern digital look." },
  { id: "demo-4", name: "Royal Blue Edition", brand: "Chronova Select", price: "4999", compare_at_price: "5999", image_url: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800", seller_name: "Time House", seller_city: "Coimbatore", category_name: "Luxury", stock_quantity: 5, warranty_months: 24, description: "A premium blue dial watch with a refined finish." },
  { id: "demo-5", name: "Minimal White Dial", brand: "Nord Time", price: "2199", compare_at_price: "2799", image_url: "https://images.unsplash.com/photo-1547996160-81dfa63595aa?w=800", seller_name: "Urban Tick Store", seller_city: "Chennai", category_name: "Women", stock_quantity: 9, warranty_months: 12, description: "Clean lines and a minimal dial for daily wear." },
  { id: "demo-6", name: "Black Sport Pro", brand: "TimeTrail", price: "1899", compare_at_price: "2499", image_url: "https://images.unsplash.com/photo-1539874754764-5a96559165b0?w=800", seller_name: "Golden Time Boutique", seller_city: "Salem", category_name: "Sports", stock_quantity: 14, warranty_months: 6, description: "A bold, sporty design for active days." },
];
const CATEGORIES = ["All", "Men", "Women", "Digital", "Luxury", "Sports"];
const money = v => `₹${Number(v || 0).toLocaleString("en-IN", { maximumFractionDigits: 0 })}`;

export default function App() {
  const [products, setProducts] = useState(DEMO);
  const [usingDemo, setUsingDemo] = useState(true);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [screen, setScreen] = useState("Home");
  const [selected, setSelected] = useState(null);
  const [cart, setCart] = useState({});
  const [wishlist, setWishlist] = useState([]);
  const [orders, setOrders] = useState([]);
  const [sort, setSort] = useState("Featured");
  const [customerName, setCustomerName] = useState("");
  const [address, setAddress] = useState("");
  const [phone, setPhone] = useState("");

  const loadCatalog = useCallback(async (refresh = false) => {
    refresh ? setRefreshing(true) : setLoading(true);
    try {
      const r = await fetch(`${API_BASE_URL}/products/`);
      if (!r.ok) throw new Error("API unavailable");
      const data = await r.json();
      const rows = Array.isArray(data) ? data : (data.results || []);
      if (rows.length) { setProducts(rows); setUsingDemo(false); }
      else { setProducts(DEMO); setUsingDemo(true); }
    } catch (_) { setProducts(DEMO); setUsingDemo(true); }
    finally { setLoading(false); setRefreshing(false); }
  }, []);
  useEffect(() => { loadCatalog(); }, [loadCatalog]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    let list = products.filter(p => {
      const hit = !q || [p.name,p.brand,p.seller_name,p.category_name,p.description].some(v => String(v || "").toLowerCase().includes(q));
      return hit && (category === "All" || String(p.category_name || "").toLowerCase() === category.toLowerCase());
    });
    if (sort === "Price: Low to High") list = [...list].sort((a,b) => Number(a.price)-Number(b.price));
    if (sort === "Price: High to Low") list = [...list].sort((a,b) => Number(b.price)-Number(a.price));
    return list;
  }, [products, search, category, sort]);

  const cartItems = products.filter(p => cart[String(p.id)] > 0);
  const cartCount = Object.values(cart).reduce((a,b) => a + Number(b || 0), 0);
  const total = cartItems.reduce((sum,p) => sum + Number(p.price || 0) * cart[String(p.id)], 0);
  const toggleWish = p => setWishlist(old => old.includes(String(p.id)) ? old.filter(id => id !== String(p.id)) : [...old, String(p.id)]);
  const addCart = (p, qty=1) => setCart(old => ({...old, [String(p.id)]: Math.max(0, Number(old[String(p.id)] || 0) + qty)}));
  const openProduct = p => { setSelected(p); setScreen("Product"); };
  const checkout = () => {
    if (!cartItems.length) { Alert.alert("Your cart is empty", "Add a watch before checkout."); return; }
    if (!customerName.trim() || !phone.trim() || !address.trim()) {
      Alert.alert("Delivery details needed", "Open Account and enter your name, phone number and delivery address first.");
      setScreen("Account"); return;
    }
    Alert.alert("Place demo order?", "This preview does not process real payments. Confirm to save a local demo order.", [
      {text:"Cancel",style:"cancel"},
      {text:"Confirm order",onPress:() => {
        const order = { id: `CW${Date.now().toString().slice(-7)}`, date: new Date().toLocaleDateString("en-IN"), total, items: cartItems.map(p=>({name:p.name,qty:cart[String(p.id)],price:p.price})), status:"Order placed" };
        setOrders(old => [order,...old]); setCart({}); setScreen("Orders");
        Alert.alert("Demo order saved", "This order is stored only on this device. No payment or shipping has been triggered.");
      }}
    ]);
  };

  const Header = ({title, back}) => <View style={s.topbar}>
    {back ? <Pressable onPress={back} style={s.back}><Text style={s.backText}>‹</Text></Pressable> : null}
    <View style={{flex:1}}><Text style={s.brand}>CHRONOVA <Text style={{color:"#fff"}}>WATCHES</Text></Text><Text style={s.tagline}>EVERY SECOND. YOUR STYLE.</Text></View>
    <Pressable onPress={()=>setScreen("Cart")} style={s.cartTop}><Text style={s.goldText}>🛒 {cartCount || ""}</Text></Pressable>
  </View>;

  const ProductCard = ({item}) => <View style={s.card}>
    <Pressable onPress={()=>openProduct(item)}>
      {item.image_url ? <Image source={{uri:item.image_url}} style={s.productImage} resizeMode="cover"/> : <View style={[s.productImage,s.placeholder]}><Text style={{fontSize:42}}>⌚</Text></View>}
      <View style={s.cardBody}><Text style={s.miniGold}>{item.brand || "CHRONOVA SELECT"}</Text><Text style={s.productName} numberOfLines={2}>{item.name}</Text><Text style={s.price}>{money(item.price)}</Text><Text style={s.oldPrice}>{item.compare_at_price ? money(item.compare_at_price) : ""}</Text><Text style={s.seller} numberOfLines={1}>{item.seller_name || "Marketplace seller"}</Text></View>
    </Pressable>
    <View style={s.cardActions}>
      <Pressable style={s.smallButton} onPress={()=>toggleWish(item)}><Text style={s.goldText}>{wishlist.includes(String(item.id)) ? "♥ Saved" : "♡ Save"}</Text></Pressable>
      <Pressable style={s.addButton} onPress={()=>{addCart(item);Alert.alert("Added to cart",`${item.name} added to your cart.`)}}><Text style={s.addText}>+ CART</Text></Pressable>
    </View>
  </View>;

  const Nav = () => <View style={s.nav}>
    {[["Home","⌂"],["Categories","▦"],["Wishlist","♡"],["Cart","🛒"],["Account","♙"]].map(([name,icon])=><Pressable key={name} onPress={()=>setScreen(name==="Categories"?"Home":name)} style={s.navItem}><Text style={[s.navIcon,screen===name&&s.navActive]}>{icon}</Text><Text style={[s.navLabel,screen===name&&s.navActive]}>{name}{name==="Cart"&&cartCount?` (${cartCount})`:""}</Text></Pressable>)}
  </View>;

  const productList = (list, title) => <><Header title={title}/><FlatList data={list} keyExtractor={p=>String(p.id)} renderItem={({item})=><ProductCard item={item}/>} numColumns={2} columnWrapperStyle={s.productRow} contentContainerStyle={s.list} ListEmptyComponent={<Text style={s.empty}>Nothing here yet.</Text>} /></>;

  let content;
  if (screen === "Home") {
    content = <><Header/><FlatList data={filtered} keyExtractor={p=>String(p.id)} renderItem={({item})=><ProductCard item={item}/>} numColumns={2} columnWrapperStyle={s.productRow} contentContainerStyle={s.list}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={()=>loadCatalog(true)} tintColor={GOLD}/>}
      ListHeaderComponent={<View>
        <View style={s.hero}><Text style={s.heroEyebrow}>THE CHRONOVA COLLECTION</Text><Text style={s.heroTitle}>Your time.{`\\n`}Your style.</Text><Text style={s.heroSub}>Discover your next favourite watch.</Text><Pressable onPress={()=>{setCategory("All");setSearch("");}} style={s.heroButton}><Text style={s.heroButtonText}>EXPLORE WATCHES →</Text></Pressable></View>
        <TextInput value={search} onChangeText={setSearch} placeholder="⌕  Search watches, brands..." placeholderTextColor={MUTED} style={s.search}/>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.categoryRow}>{CATEGORIES.map(c=><Pressable key={c} onPress={()=>setCategory(c)} style={[s.categoryChip,category===c&&s.categorySelected]}><Text style={[s.categoryText,category===c&&s.categoryTextSelected]}>{c}</Text></Pressable>)}</ScrollView>
        <View style={s.sectionRow}><Text style={s.sectionTitle}>FEATURED WATCHES</Text><Pressable onPress={()=>setSort(old=>old==="Featured"?"Price: Low to High":old==="Price: Low to High"?"Price: High to Low":"Featured")}><Text style={s.sortText}>Sort: {sort}⌄</Text></Pressable></View>
        {usingDemo?<Text style={s.notice}>DEMO CATALOG · Connect your Django API to load live products.</Text>:null}
        {loading?<ActivityIndicator color={GOLD} style={{margin:14}}/>:null}
      </View>}
      ListEmptyComponent={<Text style={s.empty}>No watches found. Try another search.</Text>}/></>;
  } else if (screen === "Product" && selected) {
    content = <><Header back={()=>setScreen("Home")}/><ScrollView contentContainerStyle={s.detailPage}>
      {selected.image_url?<Image source={{uri:selected.image_url}} style={s.detailImage} resizeMode="cover"/>:<View style={[s.detailImage,s.placeholder]}><Text style={{fontSize:70}}>⌚</Text></View>}
      <Text style={s.miniGold}>{selected.brand||"CHRONOVA SELECT"}</Text><Text style={s.detailTitle}>{selected.name}</Text><View style={s.priceLine}><Text style={s.detailPrice}>{money(selected.price)}</Text><Text style={s.oldPrice}>{selected.compare_at_price?money(selected.compare_at_price):""}</Text></View>
      <Text style={s.seller}>Sold by {selected.seller_name||"Marketplace seller"}{selected.seller_city?` · ${selected.seller_city}`:""}</Text>
      <View style={s.infoStrip}><Text style={s.infoText}>✓ {selected.warranty_months||12} month warranty</Text><Text style={s.infoText}>✓ Secure checkout preview</Text></View>
      <Text style={s.sectionTitle}>PRODUCT DETAILS</Text><Text style={s.bodyText}>{selected.description||"A stylish timepiece selected for your collection."}</Text>
      <Text style={s.bodyText}>Availability: {Number(selected.stock_quantity)>0?`${selected.stock_quantity} in stock`:"Check with seller"}</Text>
      <View style={s.detailActions}><Pressable style={s.outlineButton} onPress={()=>toggleWish(selected)}><Text style={s.goldText}>{wishlist.includes(String(selected.id))?"♥ Wishlisted":"♡ Wishlist"}</Text></Pressable><Pressable style={s.primaryButton} onPress={()=>{addCart(selected);setScreen("Cart")}}><Text style={s.primaryText}>ADD TO CART</Text></Pressable></View>
    </ScrollView></>;
  } else if (screen === "Wishlist") {
    content = productList(products.filter(p=>wishlist.includes(String(p.id))), "YOUR WISHLIST");
  } else if (screen === "Categories") {
    content = <><Header/><ScrollView contentContainerStyle={s.page}><Text style={s.pageTitle}>SHOP CATEGORIES</Text>{CATEGORIES.filter(c=>c!=="All").map(c=><Pressable key={c} style={s.menuRow} onPress={()=>{setCategory(c);setScreen("Home")}}><Text style={s.menuIcon}>⌚</Text><Text style={s.menuText}>{c} Watches</Text><Text style={s.goldText}>›</Text></Pressable>)}</ScrollView></>;
  } else if (screen === "Cart") {
    content = <><Header/><ScrollView contentContainerStyle={s.page}><Text style={s.pageTitle}>MY CART ({cartCount})</Text>{cartItems.length===0?<Text style={s.empty}>Your cart is empty. Explore watches and add your favourites.</Text>:cartItems.map(p=><View key={String(p.id)} style={s.cartItem}>{p.image_url?<Image source={{uri:p.image_url}} style={s.cartImage}/>:null}<View style={{flex:1}}><Text style={s.productName}>{p.name}</Text><Text style={s.price}>{money(p.price)}</Text><View style={s.qtyRow}><Pressable style={s.qtyButton} onPress={()=>addCart(p,-1)}><Text style={s.goldText}>−</Text></Pressable><Text style={s.qty}>{cart[String(p.id)]}</Text><Pressable style={s.qtyButton} onPress={()=>addCart(p,1)}><Text style={s.goldText}>+</Text></Pressable><Pressable onPress={()=>setCart(old=>({...old,[String(p.id)]:0}))}><Text style={s.remove}>Remove</Text></Pressable></View></View></View>)}
      {cartItems.length>0?<View style={s.summary}><Text style={s.sectionTitle}>PRICE SUMMARY</Text><View style={s.summaryRow}><Text style={s.bodyText}>Subtotal</Text><Text style={s.bodyText}>{money(total)}</Text></View><View style={s.summaryRow}><Text style={s.bodyText}>Delivery</Text><Text style={s.bodyText}>FREE</Text></View><View style={s.summaryRow}><Text style={s.totalText}>Total</Text><Text style={s.totalText}>{money(total)}</Text></View><Pressable style={s.primaryButtonFull} onPress={()=>setScreen("Checkout")}><Text style={s.primaryText}>PROCEED TO CHECKOUT</Text></Pressable></View>:null}</ScrollView></>;
  } else if (screen === "Checkout") {
    content = <><Header back={()=>setScreen("Cart")}/><ScrollView contentContainerStyle={s.page}><Text style={s.pageTitle}>CHECKOUT</Text><Text style={s.bodyText}>Delivery details</Text><TextInput value={customerName} onChangeText={setCustomerName} placeholder="Full name" placeholderTextColor={MUTED} style={s.formInput}/><TextInput value={phone} onChangeText={setPhone} placeholder="Phone number" keyboardType="phone-pad" placeholderTextColor={MUTED} style={s.formInput}/><TextInput value={address} onChangeText={setAddress} placeholder="Full delivery address" placeholderTextColor={MUTED} multiline style={[s.formInput,{minHeight:90,textAlignVertical:"top"}]}/><View style={s.summary}><Text style={s.summaryRow}>Order total: {money(total)}</Text><Text style={s.notice}>Demo checkout only. No online payment is collected and no courier is booked.</Text><Pressable style={s.primaryButtonFull} onPress={checkout}><Text style={s.primaryText}>PLACE DEMO ORDER</Text></Pressable></View></ScrollView></>;
  } else if (screen === "Orders") {
    content = <><Header/><ScrollView contentContainerStyle={s.page}><Text style={s.pageTitle}>MY ORDERS</Text>{orders.length===0?<Text style={s.empty}>No orders yet. Your confirmed demo orders will appear here.</Text>:orders.map(o=><View key={o.id} style={s.orderCard}><Text style={s.miniGold}>ORDER {o.id}</Text><Text style={s.bodyText}>{o.date} · {o.status}</Text>{o.items.map((i,n)=><Text key={n} style={s.bodyText}>{i.name} × {i.qty}</Text>)}<Text style={s.price}>Total: {money(o.total)}</Text></View>)}</ScrollView></>;
  } else {
    content = <><Header/><ScrollView contentContainerStyle={s.page}><Text style={s.pageTitle}>MY ACCOUNT</Text><View style={s.accountBadge}><Text style={s.accountLetter}>{(customerName.trim()[0]||"C").toUpperCase()}</Text><View style={{flex:1}}><Text style={s.detailTitle}>{customerName||"Welcome to Chronova"}</Text><Text style={s.seller}>Your shopping profile on this device</Text></View></View><Text style={s.formLabel}>Full name</Text><TextInput value={customerName} onChangeText={setCustomerName} placeholder="Enter your name" placeholderTextColor={MUTED} style={s.formInput}/><Text style={s.formLabel}>Phone number</Text><TextInput value={phone} onChangeText={setPhone} keyboardType="phone-pad" placeholder="Enter phone number" placeholderTextColor={MUTED} style={s.formInput}/><Text style={s.formLabel}>Delivery address</Text><TextInput value={address} onChangeText={setAddress} multiline placeholder="Enter your full address" placeholderTextColor={MUTED} style={[s.formInput,{minHeight:90,textAlignVertical:"top"}]}/><Pressable style={s.primaryButtonFull} onPress={()=>Alert.alert("Profile updated","Details are kept in this app session only in this demo.")}><Text style={s.primaryText}>SAVE PROFILE (DEMO)</Text></Pressable>{[["My Orders","Orders"],["My Wishlist","Wishlist"],["My Cart","Cart"]].map(([label,dest])=><Pressable key={label} style={s.menuRow} onPress={()=>setScreen(dest)}><Text style={s.menuText}>{label}</Text><Text style={s.goldText}>›</Text></Pressable>)}<Text style={s.notice}>Demo account: no real sign-in or cloud sync yet.</Text></ScrollView></>;
  }

  return <SafeAreaView style={s.safe}><StatusBar barStyle="light-content" backgroundColor={BG}/><View style={{flex:1}}>{content}</View>{screen!=="Product"&&screen!=="Checkout"?<Nav/>:null}</SafeAreaView>;
}

const s = StyleSheet.create({
 safe:{flex:1,backgroundColor:BG},topbar:{backgroundColor:BG,paddingHorizontal:16,paddingTop:10,paddingBottom:12,borderBottomWidth:1,borderBottomColor:"#263246",flexDirection:"row",alignItems:"center"},
 brand:{color:GOLD,fontSize:18,fontWeight:"900",letterSpacing:2},tagline:{color:"#B5A16D",fontSize:8,letterSpacing:1.6,marginTop:3},cartTop:{padding:8},goldText:{color:GOLD,fontWeight:"700"},back:{paddingRight:12},backText:{color:"#fff",fontSize:34},
 list:{paddingHorizontal:12,paddingBottom:18},hero:{marginTop:14,marginBottom:4,padding:20,borderRadius:17,backgroundColor:"#14243A",borderWidth:1,borderColor:"#4B3C21"},heroEyebrow:{color:GOLD,fontSize:10,fontWeight:"800",letterSpacing:2},heroTitle:{color:"#fff",fontSize:31,fontWeight:"800",lineHeight:36,marginTop:9},heroSub:{color:"#C3CCDA",fontSize:12,marginTop:8},heroButton:{alignSelf:"flex-start",backgroundColor:GOLD,paddingVertical:10,paddingHorizontal:14,borderRadius:8,marginTop:16},heroButtonText:{color:"#141923",fontSize:10,fontWeight:"900",letterSpacing:1},
 search:{backgroundColor:PANEL,color:"#fff",borderRadius:11,borderWidth:1,borderColor:"#2A394D",paddingHorizontal:14,paddingVertical:12,marginTop:13,fontSize:14},categoryRow:{gap:8,paddingVertical:13},categoryChip:{paddingVertical:8,paddingHorizontal:14,borderRadius:20,borderWidth:1,borderColor:"#334155",backgroundColor:PANEL},categorySelected:{backgroundColor:GOLD,borderColor:GOLD},categoryText:{color:"#D4DCE8",fontSize:12},categoryTextSelected:{color:"#101827",fontWeight:"800"},sectionRow:{flexDirection:"row",alignItems:"center",justifyContent:"space-between",marginTop:8,marginBottom:12},sectionTitle:{color:"#fff",fontWeight:"800",fontSize:12,letterSpacing:1},sortText:{color:GOLD,fontSize:10},notice:{color:"#C9AD6A",fontSize:10,lineHeight:16,marginVertical:8},
 productRow:{justifyContent:"space-between",gap:10,marginBottom:12},card:{width:"48.5%",backgroundColor:PANEL,borderRadius:13,overflow:"hidden",borderWidth:1,borderColor:"#28374B"},productImage:{width:"100%",height:145,backgroundColor:"#202C3D"},placeholder:{alignItems:"center",justifyContent:"center"},cardBody:{padding:9},miniGold:{color:GOLD,fontSize:9,letterSpacing:1,fontWeight:"800"},productName:{color:"#fff",fontSize:13,fontWeight:"700",marginTop:5,minHeight:34},price:{color:"#fff",fontSize:16,fontWeight:"900",marginTop:5},oldPrice:{color:MUTED,fontSize:10,textDecorationLine:"line-through",marginTop:2},seller:{color:MUTED,fontSize:10,marginTop:6},cardActions:{flexDirection:"row",gap:5,padding:8,paddingTop:0},smallButton:{flex:1,borderWidth:1,borderColor:"#5A4A2A",borderRadius:6,alignItems:"center",justifyContent:"center",paddingVertical:8},addButton:{flex:1,backgroundColor:GOLD,borderRadius:6,alignItems:"center",justifyContent:"center",paddingVertical:8},addText:{color:"#121826",fontSize:9,fontWeight:"900"},empty:{color:MUTED,textAlign:"center",padding:28,lineHeight:22},
 nav:{flexDirection:"row",justifyContent:"space-around",backgroundColor:"#0E1928",borderTopWidth:1,borderTopColor:"#2A394D",paddingTop:8,paddingBottom:8},navItem:{alignItems:"center",minWidth:50},navIcon:{color:MUTED,fontSize:20},navLabel:{color:MUTED,fontSize:9,marginTop:2},navActive:{color:GOLD,fontWeight:"900"},
 detailPage:{padding:16,paddingBottom:30},detailImage:{width:"100%",height:320,borderRadius:16,backgroundColor:"#202C3D",marginBottom:18},detailTitle:{color:"#fff",fontSize:23,fontWeight:"800",marginTop:6},priceLine:{flexDirection:"row",alignItems:"center",gap:10,marginTop:6},detailPrice:{color:"#fff",fontSize:25,fontWeight:"900"},infoStrip:{backgroundColor:PANEL,borderRadius:10,padding:13,marginVertical:18,gap:9},infoText:{color:"#D4DEEB",fontSize:12},bodyText:{color:"#D2D9E3",fontSize:13,lineHeight:20,marginTop:8},detailActions:{flexDirection:"row",gap:10,marginTop:24},outlineButton:{flex:1,borderWidth:1,borderColor:GOLD,borderRadius:9,alignItems:"center",justifyContent:"center",padding:14},primaryButton:{flex:1,backgroundColor:GOLD,borderRadius:9,alignItems:"center",justifyContent:"center",padding:14},primaryButtonFull:{backgroundColor:GOLD,borderRadius:9,alignItems:"center",justifyContent:"center",padding:15,marginTop:16},primaryText:{color:"#101827",fontSize:12,fontWeight:"900",letterSpacing:.5},
 page:{padding:16,paddingBottom:30},pageTitle:{color:"#fff",fontSize:22,fontWeight:"900",marginBottom:18},cartItem:{flexDirection:"row",backgroundColor:PANEL,borderRadius:12,padding:10,marginBottom:10,gap:12,borderWidth:1,borderColor:"#28374B"},cartImage:{width:88,height:100,borderRadius:8,backgroundColor:"#202C3D"},qtyRow:{flexDirection:"row",alignItems:"center",gap:12,marginTop:12},qtyButton:{width:30,height:30,borderRadius:7,borderWidth:1,borderColor:"#46556B",alignItems:"center",justifyContent:"center"},qty:{color:"#fff",fontWeight:"800"},remove:{color:"#F29C93",fontSize:11,marginLeft:5},summary:{backgroundColor:PANEL,padding:15,borderRadius:12,marginTop:10,borderWidth:1,borderColor:"#28374B"},summaryRow:{flexDirection:"row",justifyContent:"space-between",color:"#fff",marginTop:10},totalText:{color:"#fff",fontSize:16,fontWeight:"900",marginTop:12},
 formInput:{backgroundColor:PANEL,borderWidth:1,borderColor:"#334155",borderRadius:9,padding:12,color:"#fff",marginTop:7,marginBottom:13,fontSize:13},formLabel:{color:"#D6DEE9",fontSize:12,fontWeight:"700",marginTop:10},accountBadge:{flexDirection:"row",alignItems:"center",gap:12,backgroundColor:PANEL,borderRadius:12,padding:14,marginBottom:20},accountLetter:{width:45,height:45,borderRadius:23,backgroundColor:GOLD,color:BG,textAlign:"center",textAlignVertical:"center",fontSize:21,fontWeight:"900",overflow:"hidden"},menuRow:{flexDirection:"row",alignItems:"center",backgroundColor:PANEL,padding:16,borderRadius:10,marginBottom:9,borderWidth:1,borderColor:"#28374B"},menuIcon:{fontSize:22,marginRight:12},menuText:{color:"#fff",fontSize:13,fontWeight:"700",flex:1},orderCard:{backgroundColor:PANEL,padding:14,borderRadius:12,marginBottom:12,borderWidth:1,borderColor:"#28374B"}
});
