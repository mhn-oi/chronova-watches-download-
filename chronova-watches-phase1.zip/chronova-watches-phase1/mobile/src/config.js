// For public users, replace this with your deployed HTTPS API URL.
// For a physical Android phone on the same Wi-Fi, use your laptop LAN IP.
// Example: export const API_BASE_URL = "http://192.168.1.20:8000/api";
export const API_BASE_URL = "http://192.168.1.20:8000/api";
