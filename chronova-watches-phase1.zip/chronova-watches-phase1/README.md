# Chronova Watches — Android preview build

This package updates the existing Expo app with a generated Chronova icon and a shopping UI preview:
- Product catalog, search, categories and sorting
- Product details
- Local cart quantity controls and subtotal
- Local wishlist
- Local profile/delivery details
- Demo checkout and order history
- Django product catalog integration with demo fallback

## Important limitations

This is a functional **preview**, not a production-ready marketplace. Cart, wishlist, profile and orders are stored only in the running app's memory and reset when the app restarts. Demo checkout does not collect payment, place an actual server order, arrange shipping, or authenticate customers. Seller login/management and real payment gateway integration are not implemented. Use only test data.

The mobile API URL is in `mobile/src/config.js`. The current address is a local network example and will not work for customers outside your Wi-Fi. Before public release, deploy the Django API to an HTTPS host and update `API_BASE_URL`. The Django development settings in this starter must also be hardened before production.

## Backend local test

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python manage.py makemigrations catalog
python manage.py migrate
python manage.py seed_demo_data
python manage.py runserver 0.0.0.0:8000
```

For a real phone on the same Wi-Fi, find the laptop IP with `hostname -I`, then edit `mobile/src/config.js` to use `http://YOUR_LAN_IP:8000/api`. For public use, use your deployed HTTPS API URL instead.

## Build an APK with Expo EAS

Prerequisites: Node.js LTS, npm, an Expo account and internet access.

```bash
cd mobile
npm install
npx eas-cli login
npx eas-cli build:configure
npx eas-cli build --platform android --profile preview
```

When the build finishes, Expo prints a build URL. Open it and download the generated APK to your Android phone. The first cloud build may ask you to confirm Android signing credentials; allow EAS to manage them if you do not have your own keystore.

The APK must be rebuilt after code or icon changes. I cannot sign into your Expo account or trigger a build using your credentials from this package, so the commands above run on your computer.

## Current backend endpoints

- `/api/products/`
- `/api/categories/`
- `/api/sellers/`

Before launch, add customer authentication, server-side cart/order models, payment gateway integration, order status/shipping, privacy policy, security settings, and automated tests. Never store payment card data directly in this app.
